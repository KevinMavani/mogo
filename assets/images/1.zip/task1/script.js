var form = document.getElementById("form");

function handleForm(event) { event.preventDefault(); }
form.addEventListener('submit', handleForm);


var form = document.getElementById("search-form");

function handleForm(event) { event.preventDefault(); }
form.addEventListener('onkeyup', handleForm);


var dataArray = [];
var dataTable = document.getElementById("data-table");
var sortTable = document.getElementById("sort-form");
var srchTable = document.getElementById("search-form");
var sortSel = document.getElementById("sort-sel");
var editRow, rIndex;
var isSubmit = true;


function myData() {
    if (isSubmit) {
        var fname = document.getElementById("fname").value;
        var lname = document.getElementById("lname").value;
        var age = document.getElementById("age").value;
        var country = document.getElementById("country").value;

        dataArray.push({
            firstName: fname,
            lastName: lname,
            age: age,
            country: country
        });
        var row = dataTable.insertRow(dataTable.rows.length);
        var fnameCol = row.insertCell(0);
        var lnameCol = row.insertCell(1);
        var ageCol = row.insertCell(2);
        var countryCol = row.insertCell(3);
        var actions = row.insertCell(4)
        var colArray = [fnameCol, lnameCol, ageCol, countryCol, actions];

        colArray[0].innerHTML = dataArray[dataArray.length - 1].firstName;
        colArray[1].innerHTML = dataArray[dataArray.length - 1].lastName;
        colArray[2].innerHTML = dataArray[dataArray.length - 1].age;
        colArray[3].innerHTML = dataArray[dataArray.length - 1].country;
        colArray[4].innerHTML = `<button type="button" class="delete" onclick="deleteRow(this);">delete</button>
                                <button type="button" class="edit" onclick="updateForm(this);">edit</button>`;

    } else {
        updateData();
    }

    dataTable.hidden = false;
    sortTable.hidden = false;
    srchTable.hidden = false;
    document.dataForm.reset();
}

function deleteRow(elem) {
    var delRow = elem.closest("tr");
    dataArray.splice(delRow.rowIndex - 1, 1);

    delRow.remove();
    if (dataTable.rows.length == 1) {
        dataTable.hidden = true;
        sortTable.hidden = true;
        srchTable.hidden = true;
    }
    console.log(dataArray);
}

function updateForm(elem) {
    editRow = elem.closest("tr").childNodes;
    rIndex = elem.closest("tr").rowIndex - 1;

    document.getElementById("fname").value = editRow[0].textContent;
    document.getElementById("lname").value = editRow[1].textContent;
    document.getElementById("age").value = editRow[2].textContent;
    document.getElementById("country").value = editRow[3].textContent;
    isSubmit = false;

}

function updateData() {

    dataArray[rIndex].firstName = editRow[0].textContent = document.getElementById("fname").value;
    dataArray[rIndex].lastName = editRow[1].textContent = document.getElementById("lname").value;
    dataArray[rIndex].age = editRow[2].textContent = document.getElementById("age").value;
    dataArray[rIndex].country = editRow[3].textContent = document.getElementById("country").value
    document.data - form.reset();
    console.log(dataArray);
    isSubmit = true;
    sortSel.selectedIndex = 0;
}


function searchTable() {

    var selElement = document.getElementById("search-sel");
    var option = getIndex(selElement);

    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("search-input");
    filter = input.value.toUpperCase();
    table = document.getElementById("data-table");
    tr = table.getElementsByTagName("tr");

    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName("td")[Number(option.value)];
        if (td) {
            txtValue = td.textContent;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
            } else {
                tr[i].style.display = "none";
            }
        }
    }
}

function getIndex(sel) {
    var opt;
    for (var i = 0, len = sel.options.length; i < len; i++) {
        opt = sel.options[i];
        if (opt.selected === true) {
            break;
        }
    }
    return opt;

}

function sortData() {
    var selElement = document.getElementById("sort-sel");
    var opt = Number(getIndex(selElement).value);

    dataArray.sort(function(a, b) {
        let ele1, ele2;

        switch (opt) {
            case 0:
                ele1 = a.firstName;
                ele2 = b.firstName;
                return ele1 > ele2 ? 1 : -1;
            case 1:
                ele1 = a.lastName;
                ele2 = b.lastName;
                return ele1 > ele2 ? 1 : -1;
            case 2:
                ele1 = a.age;
                ele2 = b.age;
                return ele1 - ele2;
            case 3:
                ele1 = a.country;
                ele2 = b.country;
                return ele1 > ele2 ? 1 : -1;
        }
    });

    display(dataArray);
}

function display(dataArray) {
    var html = `<table id="data-table" hidden>
                    <thead>
                        <tr>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Age</th>
                            <th>Country</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                </table>`;

    for (let i = 0; i < dataArray.length; i++) {
        html += "<tr>";
        html += "<td>" + dataArray[i].firstName + "</td>";
        html += "<td>" + dataArray[i].lastName + "</td>";
        html += "<td>" + dataArray[i].age + "</td>";
        html += "<td>" + dataArray[i].country + "</td>";
        html += `<td><button type="button" class="delete" onclick="deleteRow(this);">delete</button>
                <button type="button" class="edit" onclick="updateForm(this);">edit</button></td>`;
        html += "</tr>";

    }
    dataTable.innerHTML = html;
}